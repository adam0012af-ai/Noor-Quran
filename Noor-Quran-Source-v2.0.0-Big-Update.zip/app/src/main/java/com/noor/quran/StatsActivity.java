package com.noor.quran;
import android.app.*;import android.os.*;import android.content.*;import android.view.*;import android.widget.*;
public class StatsActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b);android.content.SharedPreferences p=getSharedPreferences("noor",0);LinearLayout root=Ui.page(this,"الإحصائيات");LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(18,18,18,30);String[] a={"آخر سورة",""+p.getInt("lastS",1),"آخر آية",""+p.getInt("lastA",1),"تسبيحات المسبحة",""+p.getInt("tasCount",0),"هدف الورد",""+p.getInt("wirdTarget",5)+" صفحات","إنجاز الورد",""+p.getInt("wirdDone",0)+" صفحات"};for(int i=0;i<a.length;i+=2){LinearLayout c=Ui.card(this);c.addView(Ui.text(this,a[i],17,true));TextView v=Ui.text(this,a[i+1],27,true);v.setTextColor(Ui.EMERALD);c.addView(v);body.addView(c);Ui.gap(body,10);}root.addView(body,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
}
