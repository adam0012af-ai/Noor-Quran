package com.noor.quran;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String EXTRA_PREVIEW = "preview";

    @Override public void onReceive(Context c, Intent i) {
        android.content.SharedPreferences p = c.getSharedPreferences("noor", 0);
        boolean preview = i != null && i.getBooleanExtra(EXTRA_PREVIEW, false);
        if (!preview && !p.getBoolean("zikrOn", false)) return;
        if (!preview && p.getBoolean("quietOn", true)) {
            java.util.Calendar now = java.util.Calendar.getInstance();
            int hour = now.get(java.util.Calendar.HOUR_OF_DAY);
            int from = p.getInt("quietFrom", 23);
            int to = p.getInt("quietTo", 7);
            boolean quiet = from == to || (from < to ? hour >= from && hour < to : hour >= from || hour < to);
            if (quiet) return;
        }

        String mode = p.getString("zikrMode", "sound");
        boolean sound = "sound".equals(mode);
        boolean vibrate = "vibrate".equals(mode);
        String channelId = sound ? "azkar_sound_v2" : vibrate ? "azkar_vibrate_v2" : "azkar_silent_v2";
        String channelName = sound ? "تذكيرات الأذكار — صوت" : vibrate ? "تذكيرات الأذكار — اهتزاز" : "تذكيرات الأذكار — صامت";

        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channelId, channelName,
                    sound || vibrate ? NotificationManager.IMPORTANCE_DEFAULT : NotificationManager.IMPORTANCE_LOW);
            ch.enableVibration(vibrate);
            if (sound) {
                Uri tone = Uri.parse("android.resource://" + c.getPackageName() + "/" + R.raw.noor_reminder);
                AudioAttributes aa = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                ch.setSound(tone, aa);
            } else {
                ch.setSound(null, null);
            }
            nm.createNotificationChannel(ch);
        }

        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, channelId) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.icon)
                .setContentTitle(preview ? "نور القرآن — تجربة التذكير" : "نور القرآن — تذكير")
                .setContentText(p.getString("zikr", "اذكر الله"))
                .setStyle(new Notification.BigTextStyle().bigText(p.getString("zikr", "اذكر الله")))
                .setAutoCancel(true)
                .setContentIntent(pi);

        if (Build.VERSION.SDK_INT < 26) {
            if (sound) b.setSound(Uri.parse("android.resource://" + c.getPackageName() + "/" + R.raw.noor_reminder));
            if (vibrate) b.setVibrate(new long[]{0, 250, 150, 250});
            if (!sound && !vibrate) b.setDefaults(0);
        }
        nm.notify(preview ? 92 : 91, b.build());
    }
}
