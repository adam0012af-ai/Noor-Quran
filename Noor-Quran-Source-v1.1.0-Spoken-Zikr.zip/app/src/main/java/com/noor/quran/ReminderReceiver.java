package com.noor.quran;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import java.util.Locale;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String EXTRA_PREVIEW = "preview";
    private TextToSpeech tts;
    private PendingResult pendingResult;

    @Override public void onReceive(Context c, Intent i) {
        android.content.SharedPreferences p = c.getSharedPreferences("noor", 0);
        boolean preview = i != null && i.getBooleanExtra(EXTRA_PREVIEW, false);
        if (!preview && !p.getBoolean("zikrOn", false)) return;

        if (!preview && p.getBoolean("quietOn", true)) {
            java.util.Calendar now = java.util.Calendar.getInstance();
            int hour = now.get(java.util.Calendar.HOUR_OF_DAY);
            int from = p.getInt("quietFrom", 23);
            int to = p.getInt("quietTo", 7);
            boolean quiet = from == to || (from < to ? hour >= from && hour < to : hour >= from || hour < to);
            if (quiet) return;
        }

        String text = p.getString("zikr", "سبحان الله");
        String mode = p.getString("zikrMode", "spoken");
        boolean spoken = "spoken".equals(mode) || "sound".equals(mode); // migrate old setting
        boolean vibrate = "vibrate".equals(mode);
        String channelId = spoken ? "azkar_spoken_v4" : vibrate ? "azkar_vibrate_v4" : "azkar_silent_v4";
        String channelName = spoken ? "تذكيرات الأذكار — نطق" : vibrate ? "تذكيرات الأذكار — اهتزاز" : "تذكيرات الأذكار — صامت";

        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channelId, channelName,
                    spoken || vibrate ? NotificationManager.IMPORTANCE_DEFAULT : NotificationManager.IMPORTANCE_LOW);
            ch.enableVibration(vibrate);
            // Speech is played by Android TTS, not by notification-channel tones.
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }

        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, channelId) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.icon)
                .setContentTitle(preview ? "نور القرآن — تجربة الذكر الصوتي" : "نور القرآن — تذكير")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(pi);

        if (Build.VERSION.SDK_INT < 26) {
            if (vibrate) b.setVibrate(new long[]{0, 250, 150, 250});
            b.setSound(null);
            b.setDefaults(vibrate ? Notification.DEFAULT_VIBRATE : 0);
        }
        nm.notify(preview ? 92 : 91, b.build());

        if (spoken) speak(c.getApplicationContext(), text, preview);
    }

    private void speak(Context context, String text, boolean preview) {
        pendingResult = goAsync();
        tts = new TextToSpeech(context, status -> {
            if (status != TextToSpeech.SUCCESS) { finishSpeech(); return; }
            int lang = tts.setLanguage(new Locale("ar"));
            tts.setSpeechRate(0.88f);
            tts.setPitch(1.0f);
            if (Build.VERSION.SDK_INT >= 21) {
                tts.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build());
            }
            if (lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) {
                showTtsProblem(context, preview);
                finishSpeech();
                return;
            }
            final String id = "noor_zikr_" + System.currentTimeMillis();
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {}
                @Override public void onDone(String utteranceId) { finishSpeech(); }
                @Override public void onError(String utteranceId) { finishSpeech(); }
            });
            int r;
            if (Build.VERSION.SDK_INT >= 21) r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), id);
            else r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
            if (r == TextToSpeech.ERROR) finishSpeech();
        });
    }

    private void showTtsProblem(Context c, boolean preview) {
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        String id = "azkar_tts_help_v1";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(id, "إعداد الصوت العربي", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, id) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.icon)
                .setContentTitle("الصوت العربي غير متوفر")
                .setContentText("ثبّت أو فعّل صوتًا عربيًا في إعدادات تحويل النص إلى كلام ثم جرّب مرة أخرى.")
                .setAutoCancel(true);
        nm.notify(preview ? 94 : 93, b.build());
    }

    private synchronized void finishSpeech() {
        try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception ignored) {}
        tts = null;
        if (pendingResult != null) {
            try { pendingResult.finish(); } catch (Exception ignored) {}
            pendingResult = null;
        }
    }
}
