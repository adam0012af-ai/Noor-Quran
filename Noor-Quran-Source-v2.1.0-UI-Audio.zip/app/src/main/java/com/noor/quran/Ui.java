package com.noor.quran;
import android.app.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.widget.*;
public final class Ui{
 public static final int GREEN=Color.rgb(4,76,58),EMERALD=Color.rgb(15,139,94),GOLD=Color.rgb(206,158,52),INK=Color.rgb(24,45,37),CREAM=Color.rgb(250,249,245),MINT=Color.rgb(235,246,240);
 public static GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
 public static GradientDrawable stroke(int c,float r,int sc){GradientDrawable g=bg(c,r);g.setStroke(1,sc);return g;}
 public static TextView text(Context c,String s,float z,boolean bold){TextView v=new TextView(c);v.setText(s);v.setTextSize(z);v.setTextColor(INK);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(14,9,14,9);v.setLineSpacing(5,1.14f);v.setTextDirection(View.TEXT_DIRECTION_RTL);if(bold)v.setTypeface(null,1);return v;}
 public static Button button(Context c,String s){Button b=new Button(c);b.setText(s);b.setTextSize(15);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(bg(EMERALD,20));b.setPadding(10,8,10,8);b.setMinHeight(0);b.setMinimumHeight(0);return b;}
 public static LinearLayout card(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(12,10,12,10);l.setBackground(stroke(Color.WHITE,22,Color.rgb(229,231,227)));l.setElevation(2);return l;}
 public static void gap(LinearLayout l,int h){Space s=new Space(l.getContext());l.addView(s,new LinearLayout.LayoutParams(1,h));}
 public static LinearLayout page(Activity a,String title){a.getWindow().setStatusBarColor(GREEN);a.getWindow().setNavigationBarColor(GREEN);LinearLayout root=new LinearLayout(a);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackgroundColor(CREAM);LinearLayout bar=new LinearLayout(a);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(12,10,12,10);bar.setBackgroundColor(GREEN);TextView t=text(a,title,23,true);t.setTextColor(Color.WHITE);bar.addView(t,new LinearLayout.LayoutParams(0,-2,1));root.addView(bar);return root;}
 private Ui(){}
}
