# Noor Quran v2.1.0 — audio sources

The build workflow downloads the following human Arabic pronunciation recordings and embeds them in `app/src/main/res/raw/` before compiling.

1. **الحمد لله** — `Ar-الحمد لله.ogg`, recorded by Wikimedia Commons user ArabicAudios. License: CC BY-SA 3.0.
   Source page: https://commons.wikimedia.org/wiki/File:Ar-%D8%A7%D9%84%D8%AD%D9%85%D8%AF_%D9%84%D9%84%D9%87.ogg

2. **الله أكبر** — `Ar-eg-الله أكبر.oga`, recorded by Assem Khidhr. License: CC BY-SA 4.0.
   Source page: https://commons.wikimedia.org/wiki/File:Ar-eg-%D8%A7%D9%84%D9%84%D9%87_%D8%A3%D9%83%D8%A8%D8%B1.oga

3. **أستغفر الله** — `Ar-أستغفر الله.ogg`, recorded by Wikimedia Commons user ArabicAudios. License: CC BY-SA 3.0.
   Source page: https://commons.wikimedia.org/wiki/File:Ar-%D8%A3%D8%B3%D8%AA%D8%BA%D9%81%D8%B1_%D8%A7%D9%84%D9%84%D9%87.ogg

Attribution is retained in this file. No AI/TTS voice is used for these reminders.
