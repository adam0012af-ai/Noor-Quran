# Noor Quran v2.1.0

- Polished emerald/gold home screen with more compact cards and improved hierarchy.
- Improved full menu with icons, compact cards, consistent spacing, and clearer descriptions.
- Redesigned quick shortcuts and bottom navigation for easier one-hand use.
- Reminder UI simplified: no technical “human voice” wording.
- Added real recorded Arabic voice reminders for الحمد لله، الله أكبر، أستغفر الله.
- Audio is embedded during GitHub build and works offline in the installed APK.
- Build also publishes a source artifact that includes the downloaded audio files.
- Version updated to 2.1.0 / versionCode 21.
