# Noor Quran Human Zikr Audio Pack

Version 1.2.0 removes Android TextToSpeech from zikr reminders.
The app now plays only local human recordings from `app/src/main/res/raw/`.

Expected file names:
- zikr_subhanallah.mp3 / .ogg / .wav
- zikr_alhamdulillah.mp3 / .ogg / .wav
- zikr_allahu_akbar.mp3 / .ogg / .wav
- zikr_la_ilaha_illa_allah.mp3 / .ogg / .wav
- zikr_astaghfirullah.mp3 / .ogg / .wav
- zikr_subhanallah_wabihamdih.mp3 / .ogg / .wav
- zikr_subhanallah_alazeem.mp3 / .ogg / .wav
- zikr_salat_ala_nabi.mp3 / .ogg / .wav
- zikr_astaghfirullah_alazeem.mp3 / .ogg / .wav
- zikr_baqiyat_saliha.mp3 / .ogg / .wav

Only recordings with clear redistribution rights should be bundled.
Verified source candidates found during research include CC0/public-domain recordings on Wikimedia Commons and Freesound. Freesound original downloads require login, so source files should be downloaded once and added to res/raw before final release.
