package com.noor.quran;

import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String EXTRA_PREVIEW = "preview";
    private PendingResult pendingResult;
    private MediaPlayer player;

    @Override public void onReceive(Context c, Intent i) {
        android.content.SharedPreferences p = c.getSharedPreferences("noor", 0);
        boolean preview = i != null && i.getBooleanExtra(EXTRA_PREVIEW, false);
        if (!preview && !p.getBoolean("zikrOn", false)) return;

        if (!preview && p.getBoolean("quietOn", true)) {
            java.util.Calendar now = java.util.Calendar.getInstance();
            int hour = now.get(java.util.Calendar.HOUR_OF_DAY);
            int from = p.getInt("quietFrom", 23);
            int to = p.getInt("quietTo", 7);
            boolean quiet = from == to || (from < to ? hour >= from && hour < to : hour >= from || hour < to);
            if (quiet) return;
        }

        String text = p.getString("zikr", "سبحان الله");
        String mode = p.getString("zikrMode", "human");
        if ("spoken".equals(mode) || "sound".equals(mode)) mode = "human"; // migrate older builds
        boolean human = "human".equals(mode);
        boolean vibrate = "vibrate".equals(mode);
        String channelId = human ? "azkar_human_v1" : vibrate ? "azkar_vibrate_v5" : "azkar_silent_v5";
        String channelName = human ? "تذكيرات الأذكار — صوت بشري" : vibrate ? "تذكيرات الأذكار — اهتزاز" : "تذكيرات الأذكار — صامت";

        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(channelId, channelName,
                    human || vibrate ? NotificationManager.IMPORTANCE_DEFAULT : NotificationManager.IMPORTANCE_LOW);
            ch.enableVibration(vibrate);
            // Human voice is played by MediaPlayer, never by Android notification tone/TTS.
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }

        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, channelId) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.icon)
                .setContentTitle(preview ? "نور القرآن — تجربة الصوت البشري" : "نور القرآن — تذكير")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(pi);

        if (Build.VERSION.SDK_INT < 26) {
            if (vibrate) b.setVibrate(new long[]{0, 250, 150, 250});
            b.setSound(null);
            b.setDefaults(vibrate ? Notification.DEFAULT_VIBRATE : 0);
        }
        nm.notify(preview ? 92 : 91, b.build());

        if (human) playHumanZikr(c.getApplicationContext(), text, preview);
    }

    private void playHumanZikr(Context context, String text, boolean preview) {
        String rawName = rawNameFor(text);
        int resId = context.getResources().getIdentifier(rawName, "raw", context.getPackageName());
        if (resId == 0) {
            showMissingHumanAudio(context, text, preview);
            return;
        }
        pendingResult = goAsync();
        try {
            player = MediaPlayer.create(context, resId);
            if (player == null) { finishPlayer(); return; }
            if (Build.VERSION.SDK_INT >= 21) {
                player.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build());
            }
            player.setOnCompletionListener(mp -> finishPlayer());
            player.setOnErrorListener((mp, what, extra) -> { finishPlayer(); return true; });
            player.start();
        } catch (Exception e) {
            finishPlayer();
        }
    }

    public static String rawNameFor(String text) {
        if ("الحمد لله".equals(text)) return "zikr_alhamdulillah";
        if ("الله أكبر".equals(text)) return "zikr_allahu_akbar";
        if ("لا إله إلا الله".equals(text)) return "zikr_la_ilaha_illa_allah";
        if ("أستغفر الله".equals(text)) return "zikr_astaghfirullah";
        if ("سبحان الله وبحمده".equals(text)) return "zikr_subhanallah_wabihamdih";
        if ("سبحان الله العظيم".equals(text)) return "zikr_subhanallah_alazeem";
        if ("اللهم صل وسلم على نبينا محمد ﷺ".equals(text)) return "zikr_salat_ala_nabi";
        if ("أستغفر الله العظيم وأتوب إليه".equals(text)) return "zikr_astaghfirullah_alazeem";
        if ("سبحان الله والحمد لله ولا إله إلا الله والله أكبر".equals(text)) return "zikr_baqiyat_saliha";
        return "zikr_subhanallah";
    }

    private void showMissingHumanAudio(Context c, String text, boolean preview) {
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        String id = "azkar_human_missing_v1";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(id, "حزمة أصوات الأذكار", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, id) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.icon)
                .setContentTitle("التسجيل البشري غير موجود")
                .setContentText("لم تتم إضافة تسجيل بشري لهذا الذكر بعد: " + text)
                .setAutoCancel(true);
        nm.notify(preview ? 96 : 95, b.build());
    }

    private synchronized void finishPlayer() {
        try { if (player != null) { player.stop(); player.release(); } } catch (Exception ignored) {}
        player = null;
        if (pendingResult != null) {
            try { pendingResult.finish(); } catch (Exception ignored) {}
            pendingResult = null;
        }
    }
}
