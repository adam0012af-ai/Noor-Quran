# v1.2.0 — Human Zikr Voice Architecture

- Removed TextToSpeech dependency from reminder playback.
- Removed AI/TTS voice path entirely.
- Added local human-recording playback with MediaPlayer.
- Added deterministic per-zikr raw resource mapping.
- Added migration from legacy `spoken`/`sound` mode to `human` mode.
- Added human-audio missing-file notification instead of silently falling back to TTS.
- Updated reminder UI wording to clearly say “human voice”.
- Version bumped to 1.2.0 / versionCode 12.
